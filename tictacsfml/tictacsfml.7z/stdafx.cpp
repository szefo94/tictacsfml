// stdafx.cpp: plik �r�d�owy , kt�ry zawiera tylko standardowe zawarcia
// tictacsfml.pch b�dzie wst�pnie skompilowanym nag��wkiem
// stdafx.obj b�dzie zawiera� informacje typu wst�pnie skompilowanego

#include "stdafx.h"

// TODO: odwo�aj si� do dowolnych dodatkowych nag��wk�w, kt�rych potrzebujesz w pliku STDAFX.H
// a nie w tym pliku
