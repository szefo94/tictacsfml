#pragma once
#define SCREEN_WIDTH 768
#define SCREEN_HEIGHT 1136
#define SPLASH_STATE_SHOW_TIME 0.5
#define SPLASH_SCENE_BACKGROUND_FILEPATH ".\Resources\res\Splash Background.png"


